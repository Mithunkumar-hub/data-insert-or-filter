<?php

// click action 
if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `details` WHERE CONCAT(`s_no`,`name`,`parent_name`,`dob`,`gender`,`class`,'section') LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `details`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "school");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

<!DOCTYPE html>
<html>
    <head>
        <title> DATA SEARCH</title>
        <!-- css style -->
        <style>
            table,tr,th,td
            {
                border: 1px solid black;
                text-align:center;
            }
            table th{
                color: red;
                align-items: center;
                
            }
            .inp{
                width: 500px;
               text-align:center;
               margin-top:30px;
            }
        </style>
    </head>
    <body>
  
    <center>
    
        <form action="data_filter.php" method="post">
            <input type="text" name="valueToSearch" placeholder="Value To Search" class="inp"><br><br>
            <input type="submit" name="search" value="Filter"><br><br>
            
            <table>
                <tr>
                    <th>S_No</th>
                    <th> Name</th>
                    <th>Parent's Name</th>
                    <th>Gender</th>
                    <th>Date of Brith</th>
                    <th>School</th>
                    <th>Class</th>
                    <th>Section</th>

                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    <td><?php echo $row['s_no'];?></td>
                    <td><?php echo $row['name'];?></td>
                    <td><?php echo $row['parent_name'];?></td>
                    <td><?php echo $row['gender'];?></td>
                    <td><?php echo $row['dob'];?></td>
                    <td><?php echo $row['school'];?></td>
                    <td><?php echo $row['class'];?></td>
                    <td><?php echo $row['section'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>
    </center>
</body>
</html>