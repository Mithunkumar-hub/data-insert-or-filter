-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 28, 2022 at 04:35 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `s_no` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `parent_name` varchar(100) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `school` varchar(100) NOT NULL,
  `class` varchar(10) NOT NULL,
  `section` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`s_no`, `name`, `parent_name`, `gender`, `dob`, `school`, `class`, `section`) VALUES
(1, 'mohan', 'manu', 'male', '1998-08-23', 'motihari school', 'v', 'A'),
(2, 'sonu', 'amitab soni', 'male', '1999-06-26', 'puri meddle school', 'vii', 'B'),
(3, 'anish kumar', 'ramesh singh', 'male', '1999-04-13', 'middel school', 'v', 'A'),
(4, 'soni kumari', 'rajkumar singh', 'female', '1998-08-20', 'primary middel school', 'vii', 'B'),
(5, 'anita kumari', 'manohar sharma', 'female', '1999-09-16', 'center public school', 'viii', 'B'),
(6, 'abhishek', 'amit kumar', 'male', '1998-06-21', 'River valley primary school', 'viii', 'B'),
(7, 'sweta halder', 'mohit halder', 'female', '1995-02-12', 'center public school', 'x', 'A'),
(9, 'anita kumari', 'shshikant tiwari', 'female', '1999-07-26', 'rose primary school', 'ix', 'A'),
(10, 'manish kumari', 'sunita devi', 'female', '1995-06-11', 'shark bay school', 'vii', 'A'),
(11, 'ramesh kumar', 'sunil tiwari', 'male', '1999-09-30', 'settlers primary school', 'viii', 'B'),
(12, 'lakhan soren', 'manu soren', 'male', '1995-02-12', 'abc primary school', 'vi', 'A'),
(13, 'anit thakur', 'juganu thakur', 'female', '1998-07-22', 'gayatri school', 'viii', 'B'),
(14, 'juganu kumar', 'mithalesh soren', 'male', '1995-09-30', 'ramkrishan mission school', 'v', 'A'),
(15, 'urmila ', 'soni devi', 'female', '1997-07-28', 'middle primary school', 'x', 'B'),
(16, 'sushmita kumari ', 'anil singh', 'female', '1989-09-24', 'samson primary school', 'vii', 'A'),
(17, 'aniket kumar', 'parmod gupta', 'male', '1989-12-16', 'st.mary school', 'ix', 'B'),
(18, 'priti kumari', 'shukala singh', 'female', '1998-01-15', 'shelley primary school', 'vii', 'A'),
(19, 'mantu kumar', 'manish kumar', 'male', '1998-09-24', 'singleton primary school', 'v', 'A'),
(20, 'mukesh kumar', 'sanita devi', 'female', '1999-05-14', 'shenton school', 'viii', 'B'),
(21, 'radha kumari', 'sonita devi', 'female', '1998-08-28', 'roseworth primary school', 'x', 'B'),
(22, 'santa kumar', 'manish shukla', 'male', '1995-05-12', 'rockstar primary school', 'viii', 'A'),
(23, 'rohit kumar', 'mohit gupta', 'male', '1998-05-13', 'rohini primary school', 'vii', 'B'),
(24, 'sunita kumari', 'mithlesh bharti', 'female', '1995-08-30', 'safety bay school', 'ix', 'A'),
(25, 'doni kumar', 'rohit das', 'male', '1997-07-22', 'support primary school', 'vi', 'B'),
(26, 'vrida kumari', 'danish sinha', 'female', '1989-09-27', 'ramkrishan mission school', 'ix', 'B'),
(27, 'faisel hassn', 'mohmad hassn', 'male', '1989-12-26', 'abc primary school', 'vii', 'A'),
(28, 'soni kumari ', 'shashi sinha', 'female', '1998-08-23', 'primary school', 'ix', 'B'),
(29, 'abhi kumar ', 'kumar sinha', 'male', '1995-02-12', 'south primary school', 'ix', 'A'),
(30, 'manish kuamr', 'amit singh', 'male', '1999-09-19', 'ramkrishna  mission school ', 'ix', 'B'),
(31, 'vikash kumar', 'manish agarwal', 'female', '1995-02-13', 'govinda primary school', 'x', 'A'),
(32, 'sunita kumari', 'aniket sahu', 'female', '1998-08-24', 'A P primary school ', 'viii', 'B'),
(33, 'shubhm mahato', 'baldev mahato', 'male', '1995-05-10', 'safety primary school', 'x', 'B'),
(34, 'aniket soni', 'pankaj soni', 'male', '1998-03-12', 'salman gums school', 'vii', 'A'),
(35, 'avtika kumari', 'suman soni', 'female', '1995-09-20', 'rockstar primary school ', 'ix', 'A'),
(36, 'krishan ', 'gopi devi', 'male', '1997-07-25', 'secret star primary school', 'x', 'B'),
(37, 'sonu kumar    ', 'anita devi', 'male', '1989-09-24', 'rock primary school', 'x', 'B'),
(38, 'shashi kumar', 'kumn soren', 'male', '1989-12-18', 'sir davis primary school', 'vii', 'B'),
(39, 'chachal kumari', 'archana devi', 'female', '1998-01-15', 'lake primary school', 'ix', 'A'),
(40, 'rohan kumar', 'manish agarwal', 'male', '1998-06-24', 'rock   primary school', 'ix', 'B'),
(41, 'ram kumar', 'mani tripathi', 'male', '1998-08-20', 'motilal primary school', 'vi', 'A'),
(42, 'raju kumar', 'monika devi', 'male', '1998-12-15', 'middel primary school', 'ix', 'A'),
(43, 'rohini kumari', 'amarjeet sharma', 'female', '1999-05-12', 'rockstar primary school', 'x', 'A'),
(44, 'ravi tripathi', 'shanker tripathi', 'male', '1995-09-22', 'sir david brand school', 'x', 'A'),
(45, 'ashish kumar', 'shambhu saw', 'male', '1997-07-27', 'kadma primary school', 'v', 'A'),
(46, 'anamika kumari', 'ambika devi', 'female', '1989-09-22', 'shelley primary school', 'ix', 'A'),
(47, 'shanker tripathi ', 'amarjeet tripathi', 'male', '1989-11-26', 'safety primary school', 'vii', 'A'),
(48, 'manu trivedi', 'shushant trivedi', 'male', '1998-09-18', 'south primary school', 'vi', 'A'),
(49, 'soni gupta', 'avinash gupta', 'female', '1998-09-28', 'ramkrishan mission school', 'v', 'A'),
(50, 'amit kumar', 'shruti devi', 'female', '1999-12-14', 'south primary school', 'viii', 'A');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `details`
--
ALTER TABLE `details`
  ADD PRIMARY KEY (`s_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `details`
--
ALTER TABLE `details`
  MODIFY `s_no` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
