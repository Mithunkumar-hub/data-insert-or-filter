<?php
session_start();
$con = mysqli_connect("localhost","root","","school");

if(isset($_POST['save_multiple_data']))
{
    $name = $_POST['name'];
    $parent_name = $_POST['parent_name'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $school = $_POST['school'];
    $class = $_POST['class'];
    $section = $_POST['section'];

    foreach($name as $index => $names)
    {
        $s_name = $names;
        $s_parent_name = $parent_name[$index];
        $s_gender = $gender[$index];
        $s_dob = $dob[$index];
        $s_school = $school[$index];
        $s_class = $class[$index];
        $s_section = $section[$index];

        $query = "INSERT INTO details (name,parent_name,gender,dob,school,class,section) VALUES ('$s_name','$s_parent_name','$s_gender','$s_dob','$s_school','$s_class','$s_section')";
        $query_run = mysqli_query($con, $query);
    }

    if($query_run)
    {
        $_SESSION['status'] = "Multiple Data Inserted Successfully";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['status'] = "Data Not Inserted";
        header("Location: index.php");
        exit(0);
    }
}
?>